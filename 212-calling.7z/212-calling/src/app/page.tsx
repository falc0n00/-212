'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Upload, X, Edit, Save, Search } from 'lucide-react';
import crypto from 'crypto-js';

interface CorruptPerson {
  id: number;
  name: string;
  description: string;
  photos: string[];
  documents: string[];
}

export default function Home() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [corruptPeople, setCorruptPeople] = useState<CorruptPerson[]>([]);
  const [filteredPeople, setFilteredPeople] = useState<CorruptPerson[]>([]);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [selectedSuggestionIndex, setSelectedSuggestionIndex] = useState(-1);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    photos: [] as File[],
    documents: [] as File[]
  });

  // Updated credentials as requested
  const FIXED_USERNAME = 'ATLAS';
  const FIXED_PASSWORD = '+212gen';

  // Security: Rate limiting
  const [loginAttempts, setLoginAttempts] = useState(0);
  const [lastAttemptTime, setLastAttemptTime] = useState(0);

  // Security: Sanitize input to prevent injection
  const sanitizeInput = (input: string): string => {
    return input
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      .replace(/javascript:/gi, '')
      .replace(/on\w+\s*=/gi, '')
      .replace(/eval\(/gi, '')
      .replace(/exec\(/gi, '')
      .replace(/system\(/gi, '')
      .replace(/subprocess\(/gi, '')
      .replace(/os\./gi, '')
      .trim();
  };

  // Security: Hash sensitive data
  const hashData = (data: string): string => {
    return crypto.SHA256(data + process.env.NEXT_PUBLIC_HASH_SALT || 'default-salt').toString();
  };

  // Security: Validate input patterns
  const validateInput = (input: string): boolean => {
    const dangerousPatterns = [
      /drop\s+table/i,
      /delete\s+from/i,
      /insert\s+into/i,
      /update\s+set/i,
      /union\s+select/i,
      /exec\s*\(/i,
      /system\s*\(/i,
      /eval\s*\(/i,
      /subprocess\./i,
      /os\./i,
      /__import__/i,
      /import\s+os/i,
      /import\s+subprocess/i
    ];
    
    return !dangerousPatterns.some(pattern => pattern.test(input));
  };

  useEffect(() => {
    if (isLoggedIn) {
      fetchCorruptPeople();
    }
  }, [isLoggedIn]);

  useEffect(() => {
    // Filter people based on search term
    if (searchTerm.trim() === '') {
      setFilteredPeople(corruptPeople);
      setSuggestions([]);
      setShowSuggestions(false);
    } else {
      const filtered = corruptPeople.filter(person =>
        person.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredPeople(filtered);
      
      // Generate suggestions from names that contain the search term
      const nameSuggestions = corruptPeople
        .map(person => person.name)
        .filter(name => name.toLowerCase().includes(searchTerm.toLowerCase()))
        .slice(0, 5); // Limit to 5 suggestions
      
      setSuggestions(nameSuggestions);
      setShowSuggestions(nameSuggestions.length > 0);
    }
  }, [searchTerm, corruptPeople]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Security: Rate limiting
    const now = Date.now();
    if (now - lastAttemptTime < 5000) {
      setError('Please wait before trying again');
      return;
    }
    
    if (loginAttempts >= 5) {
      setError('Too many failed attempts. Please wait 10 minutes.');
      setTimeout(() => setLoginAttempts(0), 600000);
      return;
    }

    const sanitizedUsername = sanitizeInput(username);
    const sanitizedPassword = sanitizeInput(password);

    if (sanitizedUsername === FIXED_USERNAME && sanitizedPassword === FIXED_PASSWORD) {
      setIsLoggedIn(true);
      setError('');
      setLoginAttempts(0);
    } else {
      setError('Invalid username or password');
      setLoginAttempts(prev => prev + 1);
      setLastAttemptTime(now);
    }
  };

  const fetchCorruptPeople = async () => {
    try {
      const response = await fetch('/api/corrupt-people');
      if (response.ok) {
        const data = await response.json();
        setCorruptPeople(data);
        setFilteredPeople(data);
      }
    } catch (error) {
      console.error('Failed to fetch data:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Security: Validate inputs
    if (!validateInput(formData.name) || !validateInput(formData.description)) {
      setError('Invalid input detected. Please remove any special characters.');
      return;
    }

    const sanitizedName = sanitizeInput(formData.name);
    const sanitizedDescription = sanitizeInput(formData.description);
    
    // Security: Hash the data before sending
    const hashedName = hashData(sanitizedName);
    const hashedDescription = hashData(sanitizedDescription);
    
    const formDataToSend = new FormData();
    formDataToSend.append('name', sanitizedName);
    formDataToSend.append('description', sanitizedDescription);
    formDataToSend.append('nameHash', hashedName);
    formDataToSend.append('descriptionHash', hashedDescription);
    
    formData.photos.forEach((photo) => {
      formDataToSend.append('photos', photo);
    });
    
    formData.documents.forEach((doc) => {
      formDataToSend.append('documents', doc);
    });

    try {
      const url = editingId ? `/api/corrupt-people/${editingId}` : '/api/corrupt-people';
      const method = editingId ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        body: formDataToSend,
      });

      if (response.ok) {
        await fetchCorruptPeople();
        setFormData({ name: '', description: '', photos: [], documents: [] });
        setEditingId(null);
        setError('');
      } else {
        setError('Failed to save entry. Please try again.');
      }
    } catch (error) {
      console.error('Failed to save:', error);
      setError('An error occurred. Please try again.');
    }
  };

  const handleEdit = (person: CorruptPerson) => {
    setEditingId(person.id);
    setFormData({
      name: person.name,
      description: person.description,
      photos: [],
      documents: []
    });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'photos' | 'documents') => {
    const files = Array.from(e.target.files || []);
    
    // Security: Validate file types
    const allowedImageTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    const allowedDocTypes = ['application/pdf', 'text/plain', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    
    const validFiles = files.filter(file => {
      if (type === 'photos') {
        return allowedImageTypes.includes(file.type);
      } else {
        return allowedDocTypes.includes(file.type);
      }
    });

    if (validFiles.length !== files.length) {
      setError('Some files were rejected due to invalid file types.');
    }

    setFormData(prev => ({
      ...prev,
      [type]: [...prev[type], ...validFiles]
    }));
  };

  const removeFile = (index: number, type: 'photos' | 'documents') => {
    setFormData(prev => ({
      ...prev,
      [type]: prev[type].filter((_, i) => i !== index)
    }));
  };

  // Autocomplete handlers
  const handleSearchInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchTerm(value);
    setSelectedSuggestionIndex(-1);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setSearchTerm(suggestion);
    setShowSuggestions(false);
    setSelectedSuggestionIndex(-1);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!showSuggestions || suggestions.length === 0) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedSuggestionIndex(prev => 
          prev < suggestions.length - 1 ? prev + 1 : prev
        );
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedSuggestionIndex(prev => prev > 0 ? prev - 1 : -1);
        break;
      case 'Enter':
        e.preventDefault();
        if (selectedSuggestionIndex >= 0) {
          handleSuggestionClick(suggestions[selectedSuggestionIndex]);
        }
        break;
      case 'Escape':
        setShowSuggestions(false);
        setSelectedSuggestionIndex(-1);
        break;
    }
  };

  const handleSearchBlur = () => {
    // Delay hiding suggestions to allow click on suggestion
    setTimeout(() => {
      setShowSuggestions(false);
      setSelectedSuggestionIndex(-1);
    }, 200);
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-red-200">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold text-red-600">+212 calling</CardTitle>
            <p className="text-gray-600">Secure Corruption Reporting System</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="border-red-200 focus:border-red-400"
                  required
                  autoComplete="username"
                />
              </div>
              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="border-red-200 focus:border-red-400"
                  required
                  autoComplete="current-password"
                />
              </div>
              {error && <p className="text-red-500 text-sm">{error}</p>}
              <Button type="submit" className="w-full bg-red-600 hover:bg-red-700">
                Login
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-red-600 text-white p-4 shadow-md">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold">+212 calling</h1>
          <Button 
            onClick={() => setIsLoggedIn(false)}
            variant="outline"
            className="border-white text-white hover:bg-white hover:text-red-600"
          >
            Logout
          </Button>
        </div>
      </header>

      <main className="container mx-auto p-4">
        {/* Search Section */}
        <Card className="mb-6 border-red-200">
          <CardContent className="p-4">
            <div className="relative">
              <div className="flex items-center gap-2">
                <Search className="text-red-600" size={20} />
                <Input
                  placeholder="Search by name..."
                  value={searchTerm}
                  onChange={handleSearchInputChange}
                  onKeyDown={handleKeyDown}
                  onBlur={handleSearchBlur}
                  onFocus={() => setShowSuggestions(suggestions.length > 0)}
                  className="border-red-200 focus:border-red-400"
                />
              </div>
              
              {/* Suggestions Dropdown */}
              {showSuggestions && suggestions.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-red-200 rounded-lg shadow-lg z-50 max-h-48 overflow-y-auto">
                  {suggestions.map((suggestion, index) => (
                    <div
                      key={suggestion}
                      className={`px-3 py-2 cursor-pointer transition-colors ${
                        index === selectedSuggestionIndex
                          ? 'bg-red-100 text-red-700'
                          : 'hover:bg-red-50 text-gray-700'
                      }`}
                      onClick={() => handleSuggestionClick(suggestion)}
                      onMouseEnter={() => setSelectedSuggestionIndex(index)}
                      onMouseLeave={() => setSelectedSuggestionIndex(-1)}
                    >
                      <div className="flex items-center gap-2">
                        <Search size={14} className="text-red-400" />
                        <span className="text-sm">{suggestion}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Add/Edit Form */}
        <Card className="mb-8 border-red-200">
          <CardHeader>
            <CardTitle className="text-red-600">
              {editingId ? 'Edit Entry' : 'Add New Entry'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="border-red-200 focus:border-red-400"
                  required
                  maxLength={100}
                />
              </div>
              
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  className="border-red-200 focus:border-red-400"
                  rows={3}
                  required
                  maxLength={1000}
                />
              </div>

              <div>
                <Label>Photos (JPG, PNG, GIF, WebP)</Label>
                <div className="border-2 border-dashed border-red-200 rounded-lg p-4">
                  <input
                    type="file"
                    multiple
                    accept="image/jpeg,image/png,image/gif,image/webp"
                    onChange={(e) => handleFileChange(e, 'photos')}
                    className="hidden"
                    id="photo-upload"
                  />
                  <label htmlFor="photo-upload" className="cursor-pointer">
                    <div className="flex items-center justify-center text-red-600">
                      <Upload className="mr-2" size={20} />
                      <span>Upload Photos</span>
                    </div>
                  </label>
                  {formData.photos.length > 0 && (
                    <div className="mt-2 space-y-1">
                      {formData.photos.map((file, index) => (
                        <div key={index} className="flex items-center justify-between text-sm">
                          <span>{file.name}</span>
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => removeFile(index, 'photos')}
                          >
                            <X size={16} />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div>
                <Label>Documents (PDF, DOC, DOCX, TXT)</Label>
                <div className="border-2 border-dashed border-red-200 rounded-lg p-4">
                  <input
                    type="file"
                    multiple
                    accept=".pdf,.doc,.docx,.txt"
                    onChange={(e) => handleFileChange(e, 'documents')}
                    className="hidden"
                    id="doc-upload"
                  />
                  <label htmlFor="doc-upload" className="cursor-pointer">
                    <div className="flex items-center justify-center text-red-600">
                      <Upload className="mr-2" size={20} />
                      <span>Upload Documents</span>
                    </div>
                  </label>
                  {formData.documents.length > 0 && (
                    <div className="mt-2 space-y-1">
                      {formData.documents.map((file, index) => (
                        <div key={index} className="flex items-center justify-between text-sm">
                          <span>{file.name}</span>
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => removeFile(index, 'documents')}
                          >
                            <X size={16} />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="flex gap-2">
                <Button type="submit" className="bg-red-600 hover:bg-red-700">
                  <Save className="mr-2" size={16} />
                  {editingId ? 'Update' : 'Save'}
                </Button>
                {editingId && (
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setEditingId(null);
                      setFormData({ name: '', description: '', photos: [], documents: [] });
                      setError('');
                    }}
                  >
                    Cancel
                  </Button>
                )}
              </div>
            </form>
          </CardContent>
        </Card>

        {/* List of Corrupt People */}
        <div className="space-y-4">
          <h2 className="text-2xl font-bold text-red-600">
            List of Corrupt People ({filteredPeople.length})
          </h2>
          {filteredPeople.length === 0 ? (
            <Card className="border-red-200">
              <CardContent className="text-center py-8">
                <p className="text-gray-500">
                  {searchTerm ? 'No entries found matching your search.' : 'No entries yet. Add the first entry above.'}
                </p>
              </CardContent>
            </Card>
          ) : (
            filteredPeople.map((person) => (
              <Card key={person.id} className="border-red-200">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-red-600 mb-2">{person.name}</h3>
                      <p className="text-gray-700 mb-4">{person.description}</p>
                      
                      {person.photos && person.photos.length > 0 && (
                        <div className="mb-4">
                          <h4 className="font-medium text-gray-700 mb-2">Photos:</h4>
                          <div className="flex flex-wrap gap-2">
                            {person.photos.map((photo, index) => (
                              <img
                                key={index}
                                src={photo}
                                alt={`Photo ${index + 1}`}
                                className="w-24 h-24 object-cover border border-red-200"
                              />
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {person.documents && person.documents.length > 0 && (
                        <div>
                          <h4 className="font-medium text-gray-700 mb-2">Documents:</h4>
                          <div className="space-y-1">
                            {person.documents.map((doc, index) => (
                              <a
                                key={index}
                                href={doc}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-red-600 hover:underline block"
                              >
                                Document {index + 1}
                              </a>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex gap-2 ml-4">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEdit(person)}
                        className="border-red-200 text-red-600 hover:bg-red-50"
                      >
                        <Edit size={16} />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </main>
    </div>
  );
}