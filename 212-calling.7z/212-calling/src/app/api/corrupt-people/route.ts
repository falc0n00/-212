import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { writeFile, mkdir } from 'fs/promises';
import { join } from 'path';
import crypto from 'crypto-js';

// Security: Rate limiting
const rateLimitMap = new Map();
const RATE_LIMIT_WINDOW = 15 * 60 * 1000; // 15 minutes
const RATE_LIMIT_MAX_REQUESTS = 100;

// Security: Input sanitization
const sanitizeInput = (input: string): string => {
  return input
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/javascript:/gi, '')
    .replace(/on\w+\s*=/gi, '')
    .replace(/eval\(/gi, '')
    .replace(/exec\(/gi, '')
    .replace(/system\(/gi, '')
    .replace(/subprocess\(/gi, '')
    .replace(/os\./gi, '')
    .replace(/drop\s+table/i, '')
    .replace(/delete\s+from/i, '')
    .replace(/insert\s+into/i, '')
    .replace(/update\s+set/i, '')
    .replace(/union\s+select/i, '')
    .trim();
};

// Security: Input validation
const validateInput = (input: string): boolean => {
  const dangerousPatterns = [
    /drop\s+table/i,
    /delete\s+from/i,
    /insert\s+into/i,
    /update\s+set/i,
    /union\s+select/i,
    /exec\s*\(/i,
    /system\s*\(/i,
    /eval\s*\(/i,
    /subprocess\./i,
    /os\./i,
    /__import__/i,
    /import\s+os/i,
    /import\s+subprocess/i,
    /<script/i,
    /javascript:/i,
    /on\w+\s*=/i
  ];
  
  return !dangerousPatterns.some(pattern => pattern.test(input));
};

// Security: Rate limiting middleware
const checkRateLimit = (ip: string): boolean => {
  const now = Date.now();
  const windowStart = now - RATE_LIMIT_WINDOW;
  
  if (!rateLimitMap.has(ip)) {
    rateLimitMap.set(ip, []);
  }
  
  const requests = rateLimitMap.get(ip).filter((timestamp: number) => timestamp > windowStart);
  
  if (requests.length >= RATE_LIMIT_MAX_REQUESTS) {
    return false;
  }
  
  requests.push(now);
  rateLimitMap.set(ip, requests);
  return true;
};

// Security: Get client IP
const getClientIP = (request: NextRequest): string => {
  return request.ip || 
         request.headers.get('x-forwarded-for')?.split(',')[0] || 
         request.headers.get('x-real-ip') || 
         'unknown';
};

export async function GET(request: NextRequest) {
  try {
    const clientIP = getClientIP(request);
    
    if (!checkRateLimit(clientIP)) {
      return NextResponse.json({ error: 'Rate limit exceeded' }, { status: 429 });
    }

    const corruptPeople = await db.corruptPerson.findMany({
      orderBy: { createdAt: 'desc' }
    });
    
    const peopleWithParsedData = corruptPeople.map(person => ({
      id: person.id,
      name: person.name,
      description: person.description,
      photos: JSON.parse(person.photos || '[]'),
      documents: JSON.parse(person.documents || '[]'),
      createdAt: person.createdAt,
      updatedAt: person.updatedAt
    }));
    
    return NextResponse.json(peopleWithParsedData);
  } catch (error) {
    console.error('Error fetching corrupt people:', error);
    return NextResponse.json({ error: 'Failed to fetch data' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const clientIP = getClientIP(request);
    
    if (!checkRateLimit(clientIP)) {
      return NextResponse.json({ error: 'Rate limit exceeded' }, { status: 429 });
    }

    const formData = await request.formData();
    const name = formData.get('name') as string;
    const description = formData.get('description') as string;
    const nameHash = formData.get('nameHash') as string;
    const descriptionHash = formData.get('descriptionHash') as string;
    
    // Security: Validate required fields
    if (!name || !description || !nameHash || !descriptionHash) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Security: Input validation
    if (!validateInput(name) || !validateInput(description)) {
      return NextResponse.json({ error: 'Invalid input detected' }, { status: 400 });
    }

    // Security: Input sanitization
    const sanitizedName = sanitizeInput(name);
    const sanitizedDescription = sanitizeInput(description);
    
    // Security: Length validation
    if (sanitizedName.length > 100 || sanitizedDescription.length > 1000) {
      return NextResponse.json({ error: 'Input too long' }, { status: 400 });
    }

    // Security: Verify hashes
    const expectedNameHash = crypto.SHA256(sanitizedName + process.env.HASH_SALT || 'default-salt').toString();
    const expectedDescriptionHash = crypto.SHA256(sanitizedDescription + process.env.HASH_SALT || 'default-salt').toString();
    
    if (nameHash !== expectedNameHash || descriptionHash !== expectedDescriptionHash) {
      return NextResponse.json({ error: 'Invalid data integrity' }, { status: 400 });
    }
    
    const photos = formData.getAll('photos') as File[];
    const documents = formData.getAll('documents') as File[];
    
    // Security: Validate file types and sizes
    const allowedImageTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    const allowedDocTypes = ['application/pdf', 'text/plain', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    const maxFileSize = 10 * 1024 * 1024; // 10MB
    
    for (const photo of photos) {
      if (!allowedImageTypes.includes(photo.type) || photo.size > maxFileSize) {
        return NextResponse.json({ error: 'Invalid image file' }, { status: 400 });
      }
    }
    
    for (const doc of documents) {
      if (!allowedDocTypes.includes(doc.type) || doc.size > maxFileSize) {
        return NextResponse.json({ error: 'Invalid document file' }, { status: 400 });
      }
    }
    
    // Create uploads directory if it doesn't exist
    const uploadsDir = join(process.cwd(), 'public', 'uploads');
    try {
      await mkdir(uploadsDir, { recursive: true });
    } catch (error) {
      // Directory already exists
    }
    
    // Save photos and get URLs
    const photoUrls: string[] = [];
    for (const photo of photos) {
      if (photo.size > 0) {
        const bytes = await photo.arrayBuffer();
        const buffer = Buffer.from(bytes);
        const filename = `${Date.now()}-${Math.random().toString(36).substring(7)}-${photo.name}`;
        const filepath = join(uploadsDir, filename);
        await writeFile(filepath, buffer);
        photoUrls.push(`/uploads/${filename}`);
      }
    }
    
    // Save documents and get URLs
    const documentUrls: string[] = [];
    for (const doc of documents) {
      if (doc.size > 0) {
        const bytes = await doc.arrayBuffer();
        const buffer = Buffer.from(bytes);
        const filename = `${Date.now()}-${Math.random().toString(36).substring(7)}-${doc.name}`;
        const filepath = join(uploadsDir, filename);
        await writeFile(filepath, buffer);
        documentUrls.push(`/uploads/${filename}`);
      }
    }
    
    const corruptPerson = await db.corruptPerson.create({
      data: {
        name: sanitizedName,
        description: sanitizedDescription,
        nameHash: nameHash,
        descriptionHash: descriptionHash,
        photos: JSON.stringify(photoUrls),
        documents: JSON.stringify(documentUrls)
      }
    });
    
    const response = {
      id: corruptPerson.id,
      name: corruptPerson.name,
      description: corruptPerson.description,
      photos: JSON.parse(corruptPerson.photos),
      documents: JSON.parse(corruptPerson.documents),
      createdAt: corruptPerson.createdAt,
      updatedAt: corruptPerson.updatedAt
    };
    
    return NextResponse.json(response, { status: 201 });
  } catch (error) {
    console.error('Error creating corrupt person:', error);
    return NextResponse.json({ error: 'Failed to create entry' }, { status: 500 });
  }
}